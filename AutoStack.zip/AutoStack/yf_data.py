import datetime as dt
import matplotlib.pyplot as plt
from matplotlib import style
import pandas as pd
import pandas_datareader.data as web


stk_list = ['AAPL', 'MSFT']


def get_stock_data(stock_code=""):
    style.use('ggplot')

    start = dt.datetime(2015, 1, 1)
    end = dt.datetime.now()
    df = web.DataReader("TSLA", 'yahoo', start, end)
    df.reset_index(inplace=True)
    df.set_index("Date", inplace=True)
    # df = df.drop("Symbol", axis=1)
    print(df.head())
    df.to_csv('TSLA.csv')


if __name__ == '__main__':
    # Tickers list
    # We can add and delete any ticker from the list to get desired ticker live data
    # for item in stk_list:
    get_stock_data('item')
    pass
