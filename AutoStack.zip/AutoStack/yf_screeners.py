import requests
import yfinance as yf
import pandas as pd
import json
import numpy as np
from bs4 import BeautifulSoup


def get_data():
    stk = yf.Ticker('SPY')
    # 取得 2000 年至今的資料
    data = stk.history(start='2000-01-01')
    # 簡化資料，只取開、高、低、收以及成交量
    # data = data[['Open', 'High', 'Low', 'Close', 'Volume']]
    # 改成 TA-Lib 可以辨識的欄位名稱
    data.columns = ['open', 'high', 'low', 'close', 'volume']
    # 隨意試試看這幾個因子好了
    ta_list = ['MACD', 'RSI', 'MOM', 'STOCH']
    # 快速計算與整理因子
    for x in ta_list:
        output = eval('abstract.' + x + '(data)')
        output.name = x.lower() if type(output) == pd.core.series.Series else None
        data = pd.merge(data, pd.DataFrame(output), left_on=data.index, right_on=output.index)
        data = data.set_index('key_0')


if __name__ == '__main__':
    get_data()
